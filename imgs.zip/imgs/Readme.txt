
je pic gula paba na,, try korba onno pic use korte,, ar jodi seitao na hoy taile skip korte paro..
hubohu same pic hoite hbe emon kotha nai

4 company logo te " filter: saturate( 0% ); " use kora hoise... ete logo black&white dekhay... 
jokhn hover kore tokhn filter: saturate( 100% ); hoye jay



video link : https://youtu.be/wtqLmgcmlEg